#!/usr/bin/env python3
# The Reorder Alarm — INDEPENDENT checker. Same spec as tool/engine.js, implemented separately:
# forward reconstruction from computed opening stock (the JS engine walks backwards), csv module,
# datetime dates. Compares field-by-field with the engine's JSON output.
import csv, sys, json, io
from datetime import date, timedelta

def parse_date(s):
    p = s.strip().split("-")
    if len(p) != 3: return None
    try:
        y, m, d = int(p[0]), int(p[1]), int(p[2])
        if len(p[0])!=4 or len(p[1])!=2 or len(p[2])!=2: return None
        return date(y, m, d)
    except ValueError:
        return None

def is_pos_int(s):
    try:
        f = float(s)
        return f > 0 and f == int(f)
    except ValueError:
        return False

def r2(x): # JS Math.round(x*100)/100 — half away from zero on positives
    import math
    return math.floor(x*100+0.5)/100
def r1(x):
    import math
    return math.floor(x*10+0.5)/10

def analyze(activity_csv, stock_csv, settings=None):
    S = {"windowDays":90, "safetyDays":7, "deadDays":180, "coverDays":14}
    if settings: S.update(settings)
    refused = []
    items = {}
    sr = list(csv.reader(io.StringIO(stock_csv)))
    sh = [h.strip().lower() for h in sr[0]]
    col = {n: sh.index(n) for n in sh}
    for li, row in enumerate(sr[1:], start=2):
        if not row or len(row) < len(sh): continue
        sku = row[col["sku"]].strip()
        try:
            on_hand = float(row[col["on_hand"]]); cost = float(row[col["unit_cost"]])
            price = float(row[col["unit_price"]]); pack = float(row[col["pack_size"]])
            lead = float(row[col["lead_time_days"]])
        except ValueError:
            refused.append(("stock", li)); continue
        if (not sku or on_hand<0 or cost<0 or price<0 or pack<1 or pack!=int(pack)
            or lead<0 or lead!=int(lead)):
            refused.append(("stock", li)); continue
        items[sku] = dict(sku=sku, name=row[col["item"]].strip(), onHand=int(on_hand), cost=cost,
                          price=price, pack=int(pack), supplier=row[col["supplier"]].strip(),
                          lead=int(lead), sales={}, received={}, soldTotal=0, recTotal=0, lastSale=None)
    ar = list(csv.reader(io.StringIO(activity_csv)))
    ah = [h.strip().lower() for h in ar[0]]
    acol = {n: ah.index(n) for n in ah}
    min_d = None; max_d = None
    for li, row in enumerate(ar[1:], start=2):
        if not row or len(row) < len(ah): continue
        d = parse_date(row[acol["date"]])
        typ = row[acol["type"]].strip().upper()
        if d is None: refused.append(("activity", li)); continue
        if typ not in ("SALE","RECEIVED"): refused.append(("activity", li)); continue
        if not is_pos_int(row[acol["qty"]]): refused.append(("activity", li)); continue
        qty = int(float(row[acol["qty"]]))
        sku = row[acol["sku"]].strip()
        it = items.get(sku)
        if it is None: refused.append(("activity", li)); continue
        key = "sales" if typ=="SALE" else "received"
        it[key][d] = it[key].get(d, 0) + qty
        if typ=="SALE":
            it["soldTotal"] += qty
            if it["lastSale"] is None or d > it["lastSale"]: it["lastSale"] = d
        else:
            it["recTotal"] += qty
        if min_d is None or d < min_d: min_d = d
        if max_d is None or d > max_d: max_d = d
    if max_d is None: return {"error":"no valid activity rows"}
    today = max_d
    out = []; data_issues = []
    for it in items.values():
        opening = it["onHand"] + it["soldTotal"] - it["recTotal"]
        # forward walk
        pos = opening; min_pos = opening
        w_start = today - timedelta(days=S["windowDays"]-1)
        in_stock = 0; sold_window = 0
        d = min_d
        while d <= today:
            s = it["sales"].get(d, 0); r = it["received"].get(d, 0)
            start_pos = pos                      # position before this day's events
            if d >= w_start:
                if start_pos > 0 or s > 0: in_stock += 1
                sold_window += s
            pos = pos + r - s
            if pos < min_pos: min_pos = pos
            d += timedelta(days=1)
        if min_pos < 0 or opening < 0:
            data_issues.append(it["sku"])
        vel = sold_window/in_stock if in_stock > 0 else 0.0
        days_since = (today - it["lastSale"]).days if it["lastSale"] else None
        rop = vel*(it["lead"]+S["safetyDays"])
        cover = it["onHand"]/vel if vel > 0 else None
        if it["onHand"] > 0 and (days_since is None or days_since >= S["deadDays"]): status = "DEAD"
        elif vel == 0: status = "QUIET"
        elif it["onHand"] <= rop: status = "ORDER TODAY"
        elif it["onHand"] <= rop + vel*7: status = "ORDER THIS WEEK"
        else: status = "OK"
        suggested = 0
        if status in ("ORDER TODAY","ORDER THIS WEEK"):
            raw = vel*(it["lead"]+S["safetyDays"]+S["coverDays"]) - it["onHand"]
            if raw > 0:
                import math
                suggested = int(math.ceil(raw/it["pack"]))*it["pack"]
        dark = max(0.0, it["lead"]-cover) if (status=="ORDER TODAY" and cover is not None) else 0.0
        out.append(dict(sku=it["sku"], status=status, vel=r2(vel),
                        cover=None if cover is None else r1(cover), rop=r1(rop),
                        suggested=suggested, daysSince=days_since, cash=r2(it["onHand"]*it["cost"]),
                        soldWindow=sold_window, inStockDays=in_stock,
                        darkDays=r1(dark), riskRevenue=r2(dark*vel*it["price"]),
                        opening=opening, soldTotal=it["soldTotal"], recTotal=it["recTotal"]))
    tot_open = sum(o["opening"] for o in out); tot_sold = sum(o["soldTotal"] for o in out)
    tot_rec = sum(o["recTotal"] for o in out); tot_oh = sum(items[o["sku"]]["onHand"] for o in out)
    dead = [o for o in out if o["status"]=="DEAD"]; today_l = [o for o in out if o["status"]=="ORDER TODAY"]
    quiet = [o for o in out if o["status"]=="QUIET"]
    return {"items": {o["sku"]: o for o in out},
            "counts": {"orderToday":len(today_l), "orderWeek":sum(1 for o in out if o["status"]=="ORDER THIS WEEK"),
                        "dead":len(dead), "quiet":len(quiet),
                        "ok":sum(1 for o in out if o["status"]=="OK"), "total":len(out)},
            "money": {"orderTodayCost": r2(sum(o["suggested"]*items[o["sku"]]["cost"] for o in today_l)),
                       "deadCash": r2(sum(o["cash"] for o in dead)),
                       "quietCash": r2(sum(o["cash"] for o in quiet)),
                       "riskRevenue": r2(sum(o["riskRevenue"] for o in today_l))},
            "refusedCount": len(refused),
            "reconciles": (tot_open + tot_rec - tot_sold == tot_oh) and not data_issues,
            "dataIssues": data_issues}

if __name__ == "__main__":
    act = open(sys.argv[1]).read(); st = open(sys.argv[2]).read()
    settings = json.loads(sys.argv[3]) if len(sys.argv) > 3 else None
    print(json.dumps(analyze(act, st, settings), default=str))
