// The Reorder Alarm — FIRST BUILD (prompt 1 output, kept verbatim for the episode's wrong-turn beats).
// Bugs it shipped with, found on camera:
//   (1) velocity = lifetime units ÷ days in the file — it ignores the velocity-window setting AND
//       counts days the item was out of stock (and, for the heater, ten slow months).
//   (2) it walks the SALES file, so an item that never sold is invisible — no dead-stock entry, no cash.
//   (3) suggested order = Math.round(raw) — pack sizes ignored.
//   (4) safety days never used: reorder point = velocity × lead time only.
(function(root){
"use strict";
function parseCSV(text){
  const rows=[]; let row=[], field="", inQ=false;
  for (let i=0;i<text.length;i++){
    const c=text[i];
    if (inQ){ if (c==='"'){ if (text[i+1]==='"'){ field+='"'; i++; } else inQ=false; } else field+=c; }
    else { if (c==='"') inQ=true; else if (c===','){ row.push(field); field=""; }
      else if (c==='\n'){ row.push(field); rows.push(row); row=[]; field=""; } else if (c!=='\r') field+=c; }
  }
  if (field.length || row.length){ row.push(field); rows.push(row); }
  return rows.filter(r=>r.length>1 || (r.length===1 && r[0]!==""));
}
const DAY=86400000;
const r2=x=>Math.round(x*100)/100, r1=x=>Math.round(x*10)/10;
function analyze(activityCsv, stockCsv, settings){
  const S=Object.assign({windowDays:90, safetyDays:7, deadDays:180, coverDays:14}, settings||{});
  // stock lookup
  const srows=parseCSV(stockCsv); const sh=srows[0].map(h=>h.trim().toLowerCase());
  const si=n=>sh.indexOf(n);
  const stock=new Map();
  for (let r=1;r<srows.length;r++){ const row=srows[r];
    stock.set(row[si("sku")].trim(), {name:row[si("item")].trim(), onHand:+row[si("on_hand")], cost:+row[si("unit_cost")],
      price:+row[si("unit_price")], pack:+row[si("pack_size")], supplier:row[si("supplier")].trim(), lead:+row[si("lead_time_days")]});
  }
  // walk the sales history
  const arows=parseCSV(activityCsv); const ah=arows[0].map(h=>h.trim().toLowerCase());
  const ai=n=>ah.indexOf(n);
  const seen=new Map(); let minT=Infinity, maxT=-Infinity;
  for (let r=1;r<arows.length;r++){ const row=arows[r];
    const t=Date.parse(row[ai("date")]); if (!isFinite(t)) continue;
    const type=row[ai("type")].trim().toUpperCase(); const qty=+row[ai("qty")];
    if (type!=="SALE" || !(qty>0)) continue;
    const sku=row[ai("sku")].trim(); if (!stock.has(sku)) continue;
    if (!seen.has(sku)) seen.set(sku,{sold:0,lastT:-Infinity});
    const s=seen.get(sku); s.sold+=qty; if (t>s.lastT) s.lastT=t;
    if (t<minT)minT=t; if (t>maxT)maxT=t;
  }
  const spanDays=Math.round((maxT-minT)/DAY)+1;
  const out=[];
  for (const [sku,s] of seen){
    const it=stock.get(sku);
    const vel=s.sold/spanDays;
    const rop=vel*it.lead;
    const cover=vel>0?it.onHand/vel:null;
    const daysSince=Math.round((maxT-s.lastT)/DAY);
    let status;
    if (it.onHand>0 && daysSince>=S.deadDays) status="DEAD";
    else if (it.onHand<=rop) status="ORDER TODAY";
    else if (it.onHand<=rop+vel*7) status="ORDER THIS WEEK";
    else status="OK";
    let suggested=0;
    if (status==="ORDER TODAY"||status==="ORDER THIS WEEK"){
      suggested=Math.max(0, Math.round(vel*(it.lead+S.coverDays)-it.onHand));
    }
    out.push({sku,name:it.name,supplier:it.supplier,onHand:it.onHand,pack:it.pack,lead:it.lead,cost:it.cost,price:it.price,
      vel:r2(vel),cover:cover===null?null:r1(cover),rop:r1(rop),status,suggested,daysSince,cash:r2(it.onHand*it.cost)});
  }
  const by=s=>out.filter(o=>o.status===s);
  const orderToday=by("ORDER TODAY"), dead=by("DEAD");
  out.sort((a,b)=>{const rank=s=>({"ORDER TODAY":0,"ORDER THIS WEEK":1,"DEAD":2,"OK":3}[s]);
    return rank(a.status)-rank(b.status) || b.cash-a.cash || a.sku.localeCompare(b.sku);});
  return {settings:S, today:maxT, items:out,
    counts:{orderToday:orderToday.length, orderWeek:by("ORDER THIS WEEK").length, dead:dead.length, ok:by("OK").length, total:out.length},
    money:{orderTodayCost:r2(orderToday.reduce((a,o)=>a+o.suggested*o.cost,0)), deadCash:r2(dead.reduce((a,o)=>a+o.cash,0))}};
}
const api={analyze};
if (typeof module!=="undefined" && module.exports) module.exports=api;
root.RA_V1=api;
})(typeof window!=="undefined"?window:globalThis);
